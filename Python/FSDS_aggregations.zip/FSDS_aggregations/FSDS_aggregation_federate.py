#FSDS aggregation procedures:

from ood_vimp_wrapper import MMD_LOCO, RF_domain_classifier, permuCATE_vimp 
from scipy.stats import spearmanr
import itertools 
import numpy as np 
from math import factorial 

#The aggregated versions of the various notions of the variable importances
#including the pseudo-outcome risk, random forest binary classifier and the
#MMD(maximal mean discrepancy)-LOCO(leave-one-covariate-out)
def vimp_wrapper(X_ref, X_new, Y_ref, Y_new, seed):
    X = np.vstack([X_ref, X_new])
    Y = np.concatenate([Y_ref, Y_new])
    T = np.concatenate([np.zeros(len(X_ref)), np.ones(len(X_new))])
    po, po_sd, po_med = permuCATE_vimp(X, Y, T, n_perm = N_PERM, seed = seed)
    rf = RF_domain_classifier(X_ref, X_new, seed = seed)
    mmd = MMD_LOCO(X_ref, X_new, max_n = MMD_MAX_N, seed = seed)
    return {
        'po': np.asarray(po, dtype = float),
        'po_sd': np.asarray(po_sd, dtype = float),
        'rf': np.asarray(rf, dtype = float),
        'mmd': np.asarray(mmd, dtype = float),
    }

#The various aggregation procedures:
def uniform_agg(stack):
    return np.asarray(stack, dtype = float).mean(axis = 0)

#Sample weights aggregation with the sample-sizes
def n_weighted_agg(stack, sizes):
    w = np.asarray(sizes, dtype = float)
    w = w / w.sum()
    return (w[:, None] * np.asarray(stack, dtype = float)).sum(axis = 0)
def median_agg(stack):
    return np.median(np.asarray(stack, dtype = float), axis = 0)
#inverse variance weighting:
def ivw(vimp, std):
    varis = np.asarray(std, dtype = float) ** 2 + 1e-4
    w = 1.0 / varis
    w = w / w.sum(axis = 0, keepdims = True)
    return (w * np.asarray(vimp, dtype = float)).sum(axis = 0)

#The pairwise alignment between the two sets of VIMPs
def pairwise_alignment(V, S):
    if len(S) <= 1:
        return 0.0
    vals = []
    for a, b in itertools.combinations(S, 2):
        rho = spearmanr(V[a], V[b]).statistic
        vals.append(0.0 if np.isnan(rho) else float(rho))
    return float(np.mean(vals))

#The shapley weights procedure:
def shapley_weights(V, ns):
    k = len(V)
    phi = np.zeros(k)
    for i in range(k):
        rest = [j for j in range(k) if j != i]
        for r in range(len(rest) + 1):
            coef = factorial(r) * factorial(k - r - 1) / factorial(k)
            for S in itertools.combinations(rest, r):
                S = list(S)
                phi[i] += coef * (
                    coalition_agreement(V, S + [i]) - coalition_agreement(V, S))
    phi = np.maximum(phi, 0.0)
    if phi.sum() < 1e-8:
        return np.asarray(ns, dtype = float) / np.sum(ns)

'''
Pool the rankings for the indiviudal subset blocks with the indiviudal 
FSDS rankings with the notions include both the PO-risk, RF-Domain Binary Classifier and the MMD-LOCO
'''
def pool_rankings(stack, sizes, fsds_vec, std = None):
    pooled = {
        'uniform': stack.mean(axis = 0),
        'n_weighted': n_weighted(stack, sizes),
        'median': median_agg(stack),
    }
    w = shapley_weights(stack, sizes)
    pooled['shapley'] = (w[:, None] * stack).sum(axis = 0)
    pooled['topk3'] = n_weighted(np.vstack([topk_mask(v, 3) for v in stack]), sizes)
    pooled['topk5'] = n_weighted(np.vstack([topk_mask(v, 5) for v in stack]), sizes)
    if std is not None:
        pooled['ivw'] = ivw(stack, std)
    return {
        'fsds_ranking': np.argsort(-fsds_vec),
        'pooled_ranking': {name: np.argsort(-vec) for name, vec in pooled.items()},
        'spearman': {
            name: float(spearmanr(vec, fsds_vec).statistic)
            for name, vec in pooled.items()
        },
    }


'''
# FSDS pair: shuffle, half reference, half new, shift the first 3 columns of the new batch.
n = (len(y) // (2 * K)) * (2 * K)
X, y = X[:n], y[:n]
n_batch = n // 2
X_ref, Y_ref = X[:n_batch].copy(), y[:n_batch].copy()
X_new, Y_new = X[n_batch:].copy(), y[n_batch:].copy()
X_new[:, :SHIFT_DIMS] += SHIFT#covariate shift injected
# Full-sample FSDS result.
fsds = vimp_wrapper(X_ref, X_new, Y_ref, Y_new, seed = 2026)
# Same row indices on the reference batch and the new batch.
fold_n = n_batch // K
sample_indice_list = [np.arange(k * fold_n, (k + 1) * fold_n) for k in range(K)]
folds = []
for i, rows in enumerate(sample_indice_list):
    folds.append(one_vimp(
        X_ref[rows], X_new[rows], Y_ref[rows], Y_new[rows],
        seed = 20261004 + 17 * (i + 1)))
sizes = np.full(K, fold_n, dtype = float)
out = {}
for key in ('po', 'rf', 'mmd'):
    stack = np.vstack([f[key] for f in folds])
    std = np.vstack([f['po_sd'] for f in folds]) if key == 'po' else None
    out[key] = pool_rankings(stack, sizes, fsds[key], std = std)
print(out)#output the whole results here.
'''


