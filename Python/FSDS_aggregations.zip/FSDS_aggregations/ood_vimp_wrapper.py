#OOD_VIMP_wrapper:

"""
Returning the three versions of the procedures:
[1] Pseudo-outcome risk via the PermuCATE and LOCO
[2] RF(Random Forest) domain classifier
[3] MMD LOCO(leave-one-covariate-out) procedure
For the blockwise federated procedure for attributing the 
distribution shift and the variable importance to be pooled together
for each of the dimension.
"""

from __future__ import annotations

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from benchmark_config import MODEL_REGISTRY


def _as_1d(X):
    return np.asarray(X).reshape(-1)


def po_risk(tau, Y, T, mu0, mu1, pi, clip=1e-3):
    pi_clip = np.clip(pi, clip, 1 - clip)
    pseudo = (Y - np.where(T == 1, mu1, mu0)) * (T - pi_clip) / (
        pi_clip * (1 - pi_clip)
    ) + (mu1 - mu0)
    return np.mean((pseudo - tau) ** 2)


def infer_feature_type(X):
    p = X.shape[1]
    feature_types = ["continuous"] * p
    for j in range(p):
        n_level = np.unique(X[:, j]).size
        if n_level == 2:
            feature_types[j] = "binary"
        elif n_level <= 5:
            feature_types[j] = "categorical"
    return feature_types


def permuCATE_fit_nuisance(
    X, Y, W,
    model_registry=MODEL_REGISTRY,
    model_m="rf_regressor",
    model_e="logistic_classifier",
    model_tau="rf_regressor",
    model_nu="rf_regressor",
    model_nu_bi="logistic_classifier",
    model_nu_multi="multinomial_classifier",
    clip_e=1e-2,
    seed=2026,
):
    X = np.asarray(X)
    Y = _as_1d(Y)
    W = _as_1d(W).astype(int)
    n, p = X.shape
    model_outcome0 = model_registry[model_m]
    model_outcome1 = model_registry[model_m]
    model_propensity_score = model_registry[model_e]
    model_tau_spec = model_registry[model_tau]
    X_ctr, X_trt = X[W == 0], X[W == 1]
    Y_ctr, Y_trt = Y[W == 0], Y[W == 1]
    mu0_fit = model_outcome0["fit"](X_ctr, Y_ctr, seed=seed)
    mu1_fit = model_outcome1["fit"](X_trt, Y_trt, seed=seed)
    mu0_est = model_outcome0["predict"](mu0_fit, X)
    mu1_est = model_outcome1["predict"](mu1_fit, X)
    model_e_fit = model_propensity_score["fit"](X, W, seed=seed + 2)
    pi_est = np.clip(model_propensity_score["predict"](model_e_fit, X), clip_e, 1 - clip_e)
    pseudo_outcome = mu1_est - mu0_est + (
        Y - np.where(W == 1, mu1_est, mu0_est)
    ) * (W - pi_est) / (pi_est * (1.0 - pi_est))
    model_tau_fit = model_tau_spec["fit"](X, pseudo_outcome, seed=seed + 3)
    tau_est = model_tau_spec["predict"](model_tau_fit, X)
    feature_types = infer_feature_type(X)
    nu_model = {}
    for j in range(p):
        if feature_types[j] == "continuous":
            model_nu_spec = model_registry[model_nu]
        else:
            X[:, j] = LabelEncoder().fit_transform(X[:, j])
            model_nu_spec = model_registry[
                model_nu_bi if feature_types[j] == "binary" else model_nu_multi
            ]
        model_nu_fit = model_nu_spec["fit"](
            np.delete(X, j, axis=1), X[:, j], seed=seed + j + 100
        )
        nu_model[j] = {"model_nu": model_nu_spec, "model_nu_fit": model_nu_fit}
    return {
        "model_outcome0": model_outcome0,
        "model_outcome1": model_outcome1,
        "model_propensity_score": model_propensity_score,
        "model_tau": model_tau_spec,
        "mu0_fit": mu0_fit,
        "mu1_fit": mu1_fit,
        "model_e_fit": model_e_fit,
        "model_tau_fit": model_tau_fit,
        "mu0_est": mu0_est,
        "mu1_est": mu1_est,
        "pi_est": pi_est,
        "tau_est": tau_est,
        "pseudo_outcome": pseudo_outcome,
        "nu_model": nu_model,
    }



def permuCATE_vimp(
    X, Y, W,
    model_registry=MODEL_REGISTRY,
    model_m="rf_regressor",
    model_e="logistic_classifier",
    model_tau="rf_regressor",
    model_nu="rf_regressor",
    model_nu_bi="logistic_classifier",
    model_nu_multi="multinomial_classifier",
    n_perm=100,
    test_size=0.5,
    seed=0,
    clip_e=0.01,
    normalize=False,
):
    X = np.asarray(X)
    Y = _as_1d(Y)
    W = _as_1d(W).astype(int)
    X_train, X_test, W_train, W_test, Y_train, Y_test = train_test_split(
        X, W, Y, test_size=test_size, stratify=W, random_state=seed
    )
    n, p = X.shape
    rng = np.random.default_rng(seed)
    outputs = permuCATE_fit_nuisance(
        X_train, Y_train, W_train,
        model_registry=model_registry,
        model_m=model_m, model_e=model_e, model_tau=model_tau,
        model_nu=model_nu, model_nu_bi=model_nu_bi, model_nu_multi=model_nu_multi,
        clip_e=clip_e, seed=seed,
    )
    tau_est = outputs["model_tau"]["predict"](outputs["model_tau_fit"], X_new=X_test)
    mu0_test = outputs["model_outcome0"]["predict"](outputs["mu0_fit"], X_new=X_test)
    mu1_test = outputs["model_outcome1"]["predict"](outputs["mu1_fit"], X_new=X_test)
    pi_test = np.clip(
        outputs["model_propensity_score"]["predict"](outputs["model_e_fit"], X_new=X_test),
        clip_e, 1 - clip_e,
    )
    po_risk_original = po_risk(tau_est, Y_test, W_test, mu0_test, mu1_test, pi_test)
    vimp = np.zeros(p, dtype=float)
    vimp_sd = np.zeros(p, dtype = float)
    vimp_median = np.zeros(p, dtype = float)
    for j in range(p):
        rng = np.random.default_rng(seed+j)
        nu_spec = outputs["nu_model"][j]["model_nu"]
        nu_fit = outputs["nu_model"][j]["model_nu_fit"]
        nu_hat = nu_spec["predict"](nu_fit, np.delete(X_test, j, axis=1)).ravel()
        residual = (X_test[:, j] - nu_hat).ravel()
        drops = np.zeros(n_perm, dtype=float)
        for k in range(n_perm):
            X_perm = X_test.copy()
            X_perm[:, j] = nu_hat + rng.permutation(residual)
            tau_perm = outputs["model_tau"]["predict"](outputs["model_tau_fit"], X_perm)
            drops[k] = po_risk(tau_perm, Y_test, W_test, mu0_test, mu1_test, pi_test) - po_risk_original
        vimp[j] = drops.mean()
        vimp_sd[j] = drops.std()
        vimp_median[j] = float(np.median(drops))
    #output the site-specific statistic:
    if normalize:
        return vimp / np.sum(vimp)
    return vimp, vimp_sd, vimp_median


# ---------------------------------------------------------------------------
# 2. RF domain classifier
# ---------------------------------------------------------------------------

def RF_domain_classifier(X_ref, X_new, seed=0):
    """Random-forest importance for predicting which batch a row came from."""
    X_ref = np.asarray(X_ref, dtype=float)
    X_new = np.asarray(X_new, dtype=float)
    X = np.vstack([X_ref, X_new])
    W = np.concatenate([np.zeros(len(X_ref)), np.ones(len(X_new))]).astype(int)
    p = X.shape[1]
    clf = RandomForestClassifier(
        n_estimators=150,
        max_depth=max(2, int(np.round(np.sqrt(p)))),
        min_samples_leaf=max(1, int(np.round(np.sqrt(len(X)) // 2))),
        n_jobs=1,
        random_state=seed,
    )
    clf.fit(X, W)
    return clf.feature_importances_


# ---------------------------------------------------------------------------
# 3. MMD-LOCO
# ---------------------------------------------------------------------------

def _rbf_gamma(X, Y, max_samples=400):
    n_x, n_y = X.shape[0], Y.shape[0]
    if n_x + n_y > max_samples:
        rng = np.random.default_rng(0)
        idx_x = rng.choice(n_x, size=min(n_x, max_samples // 2), replace=False)
        idx_y = rng.choice(n_y, size=min(n_y, max_samples // 2), replace=False)
        Z = np.vstack([X[idx_x], Y[idx_y]])
    else:
        Z = np.vstack([X, Y])
    sq = np.sum((Z[:, None, :] - Z[None, :, :]) ** 2, axis=2)
    positive = sq[sq > 0]
    if positive.size == 0:
        return 1.0
    return 1.0 / float(np.median(positive))


def rbf_mmd2(X, Y, gamma=None):
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    if gamma is None:
        gamma = _rbf_gamma(X, Y)
    XX = np.sum((X[:, None, :] - X[None, :, :]) ** 2, axis=2)
    YY = np.sum((Y[:, None, :] - Y[None, :, :]) ** 2, axis=2)
    XY = np.sum((X[:, None, :] - Y[None, :, :]) ** 2, axis=2)
    return float(
        np.mean(np.exp(-gamma * XX))
        + np.mean(np.exp(-gamma * YY))
        - 2.0 * np.mean(np.exp(-gamma * XY))
    )

class MMD:
    def __init__(self, compute_kernel="rbf"):
        if compute_kernel != "rbf":
            raise ValueError(f"unsupported kernel: {compute_kernel}")
        self._gamma = None
    def __call__(self, X, Y):
        if self._gamma is None:
            self._gamma = _rbf_gamma(np.asarray(X), np.asarray(Y))
        return rbf_mmd2(X, Y, gamma=self._gamma), None


def MMD_LOCO(X_ref, X_new, max_n=1000, seed=0):
    """Full-sample RBF MMD minus MMD after dropping feature j."""
    rng = np.random.default_rng(seed)
    X_ref = np.asarray(X_ref, dtype=float)
    X_new = np.asarray(X_new, dtype=float)
    if len(X_ref) > max_n:
        X_ref = X_ref[rng.choice(len(X_ref), size=max_n, replace=False)]
    if len(X_new) > max_n:
        X_new = X_new[rng.choice(len(X_new), size=max_n, replace=False)]
    mmd_test = MMD(compute_kernel="rbf")
    mmd_orig, _ = mmd_test(X_ref, X_new)
    p = X_ref.shape[1]
    mmd_drop = np.zeros(p, dtype=float)
    for j in range(p):
        mmd_drop[j], _ = mmd_test(
            np.delete(X_ref, j, axis=1), np.delete(X_new, j, axis=1)
        )
    return mmd_orig - mmd_drop


#predictive variable importance wrapper here:
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import roc_auc_score, average_precision_score
#prediction variable importance for the MSE or the brier score
def brier_L2(Y_hat, Y_gt):
    Y_levels = max(Y_hat)
    n = len(Y_hat)
    Y_gt_l2 = np.zeros((n, Y_levels))
    Y_gt_l2[np.arange(n), Y_gt] = 1
    Y_level_l2 = np.zeros((n, Y_levels))
    Y_level_l2[np.arange(n), Y_hat] = 1
    brier_L2 = ((Y_gt_l2 - Y_level_l2) ** 2).sum(axis = 1)
    return np.array(brier_L2)

def pred_vimp_wrapper(df,
    model_registry = MODEL_REGISTRY, 
    model_m = 'rf_regressor',
    seed = 1024,
    n_perm = 100):
    df_train, df_test = train_test_split(df, test_size = 0.3)
    df1_X = df_train[:, :df_train.shape[1]-1]
    df2_X = df_test[:, :df_test.shape[1]-1]
    df1_Y = df_train[:, df_train.shape[1]-1].reshape(-1, 1)
    df2_Y = df_test[:, df_test.shape[1]-1].reshape(-1, 1)
    n1, p = df.shape 
    model_m = model_registry[model_m]
    model_fit = model_m['fit'](df1_X, df1_Y)
    pred_Y_orig = model_m['predict'](model_fit, df1_Y)
    mse_orig = np.mean((df1_Y - pred_Y_orig) ** 2)
    mse_perm = np.zeros((p, n_perm))
    for j in range(p):
        for k in range(n_perm):
            df2_X_new = df2_X.copy()
            rng = np.random.default_rng(seed = seed + j + k)
            df2_X_new[:, j] = rng.permutation(df2_X_new[:, j])
            df2_pred = model_m['predict'](model_fit, df2_X_new)
            mse_perm[j, k] = np.mean((df2_Y - 
                df2_pred) **2) - mse_orig
    vimp_std = np.array(mse_perm.std(axis = 0))
    vimp_mean = np.array(mse_perm.mean(axis = 0))
    return {
    'vimp_std': vimp_std,
    'vimp_mean': vimp_mean
    }
            

def pred_vimp_wrapper_loco(df, model_registry = MODEL_REGISTRY,
    model_m = 'rf_regressor', seed = 1024):
    df_train, df_test = train_test_split(df, test_size = 0.3)
    df1_X = df_train[:, :df_train.shape[1]-1]
    df2_X = df_test[:, :df_test.shape[1]-1]
    df1_Y = df_train[:, df_train.shape[1]-1].reshape(-1, 1)
    df2_Y = df_test[:, df_test.shape[1]-1].reshape(-1, 1)
    n1, p = df.shape 
    model_m = model_registry[model_m]
    model_fit = model_m['fit'](df1_X, df1_Y)
    pred_Y_orig = model_m['predict'](model_fit, df1_Y)
    mse_orig = np.mean((df1_Y - pred_Y_orig) ** 2)
    mse_loco = np.zeros(p)
    for j in range(p):
        df2_X_new = df2_X.copy()
        df1_X_new = df1_X.copy()
        model_fit_new = model_m['fit'](np.delete(df1_X_new, j, 1),
            df1_Y)
        df2_Y_new = model_m['predict'](model_fit_new, df2_X_new)
        mse_loco[j] = np.mean((df2_Y - df2_Y_new)**2) - mse_orig 
    return mse_loco
        

#The wrapper for the out-of-distribution variable importance here for visualization:
def ood_vimp_wrapper(df1, df2, 
    n_perm = 25):
    n1, p = df1.shape 
    n2 = df2.shape[0]
    df1 = np.asarray(df1, dtype = float)
    df2 = np.asarray(df2, dtype = float)
    df1_X = df1[:, :df1.shape[1]-1]
    df2_X = df2[:, :df2.shape[1]-1]
    X = np.vstack([df1_X, df2_X])
    Y = np.concatenate([df1[:,-1],
        df2[:,-1]]).reshape(-1, 1)
    T = np.concatenate(
        [np.zeros(n1),
         np.ones(n2)]
        ).reshape(-1, 1)
    po_vimp, po_vimp_sd, po_vimp_median = permuCATE_vimp(X, Y, T, n_perm=n_perm)
    rf_vimp = RF_domain_classifier(df1_X, df2_X)
    MMD_vimp = MMD_LOCO(df1_X, df2_X, max_n = max(n1, n2))
    return {
    'po_vimp': po_vimp,
    'po_vimp_sd': po_vimp_sd,
    'po_vimp_median': po_vimp_median,
    'rf_vimp': rf_vimp,
    'MMD_vimp': MMD_vimp
    }

