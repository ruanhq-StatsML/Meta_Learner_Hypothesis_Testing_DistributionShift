#Aggregating the individual model together:
from benchmark_config import MODEL_REGISTRY
from onlinePermOOB import *
from scipy.stats import spearmanr
from scipy.stats import binom

def _as_block_matrix(p_values):
    p = np.asarray(p_values, dtype = float)
    if p.ndim == 1:
        p = p.reshape(1, -1)
    return p

#CFGA aggregation:
def cfga_aggregation(p_values, alpha = ALPHA):
    p = _as_block_matrix(p_values)
    n_blocks = p.shape[1]
    mid = n_blocks // 2 
    halves = (np.arange(0, mid), np.arange(mid, n_blocks))
    out = np.empty(len(p))
    for t in np.arange(len(p)):
        row = p[t]
        fold_p = []
        #split into two halves and cut them to find the optimal threshold and how many beyond that value here.
        for rank_idx, score_idx in (halves, halves[::-1]):
            rank = np.sort(row[rank_idx])
            k = len(rank)
            thr = 0.0 
            for j in range(k, 0, -1):
                cut = (j / k) * (alpha / 2.0)
                if rank[j - 1] <= cut:
                    thr = cut 
                    break 
            if thr <= 0.0:
                fold_p.append(1.0)
                continue 
            hits = int(np.sum(row[score_idx] <= thr))
            if hits == 0:
                fold_p.append(1.0)
            else:
                fold_p.append(float(binom.sf(hits - 1,
                    len(score_idx), min(thr, 1.0))))#binom.sf(k, n, p)-> cdf for binomial
        out[t] = min(1.0, 2.0 * min(fold_p))
    return out

#Cauchy Aggregation for the p-values across individual subsets:
#Input the p-value paths:
def cauchy_aggregation(p_values, weights):
    T_stats = np.sum(weights * np.tan(0.5 - p_values) * np.pi)
    p_combined = 0.5 - np.arctan(T_stats/np.sum(weights))/np.pi
	return p_combined

#fisher aggregation:
def fisher_aggregation(p_values, weights = None):
    p = np.clip(_as_block_matrix(p_values), axis = 1)
    stat = -2.0 * np.sum(np.log(p), axis = 1)
    return np.clip(1.0 - chi2.cdf(stat, df = 2 * p.shape[1]), 0.0, 1.0)

#Harmonic procedure for the p-value aggregation:
def hmp_aggregation(p_values, weights):
    p_values = np.clip(p_values, 1e-8, 1.0 - 1e-8)
    p_val_agg = np.sum(weights)/(np.sum(weights/p_values))
    return p_val_agg

#Simes Aggregation for the p-values:
def simes_aggregation(p_values, weights = None):
    p = np.sort(p_values, axis = 1)
    m = p.shape[1]
    return np.minimum(1.0, np.min(p * m/np.arange(1, m + 1), axis = 1))

def stouffer(ps, weights = None):
    z = norm.ppf(1.0 - np.clip(ps, 1e-12, 1.0 - 1e-12))
    if weights is None:
        z_bar = np.sum(z)/ np.sqrt(len(z))
    else:
        w = np.asarray(weights, dtype = float)
        z_bar = np.sum(w * z)/ np.sqrt(np.sum(w ** 2))
    return float(np.clip(1.0 - norm.cdf(z_bar), 0.0, 1.0))

def ssfed_p(p_values):
    p_values = np.clip(np.asarray(p_values, dtype = float),
        1e-4, 1.0)
    return stouffer(p, weights = 1.0/p)
    

#output the pval and the significance path for the 
#addis and the saffron procedures:
def onlinePermOOB_Path(
    df,
    batch_size=10,
    ref_batch_size=1000,
    model_registry=MODEL_REGISTRY,
    model_m="rf_regressor",
    burnin=5,
    seed=2026,
    alpha=0.05,
):
    df = np.asarray(df, dtype=float)
    p = df.shape[1]
    ref = df[:ref_batch_size, :]
    model = model_registry[model_m]
    fit = model["fit"](ref[:, : p - 1], ref[:, p - 1], seed=seed)
    trail = df[ref_batch_size:, :]
    mse = []
    for i in range(0, len(trail), batch_size):
        batch = trail[i : i + batch_size, :]
        if len(batch) < batch_size:
            break
        y_hat = model["predict"](fit, batch[:, : p - 1])
        mse.append(float(np.mean((batch[:, p - 1] - y_hat) ** 2)))
    pval = np.asarray(empirical_pval(mse, burnin=burnin), dtype=float)
    sig_addis = method_addis(pval, alpha=alpha).astype(int)
    sig_saffron = method_saffron(pval, alpha=alpha).astype(int)
    return {
        "mse": np.asarray(mse, dtype=float),
        "pval": pval,
        "sig_addis": sig_addis,
        "sig_saffron": sig_saffron,
    }

#Aggregate the significance paths across individual blocks
'''
Input the indice_list for the subsets of the features - 
the various p-value aggregation procedures:
Harmonic Mean, Simes, Fisher, SSFed(ss federated procedure),
Cauchy(Cauchy Aggregation) and the Stouffer procedure
Output the significance paths via the online multiple testing procedures
like ADDIS and SAFFRON
'''
def aggregate_significance(df, indice_list, batch_size = 10,
    ref_size = 1000, model_registry = MODEL_REGISTRY,
    model_m = 'rf_regressor'):
    path_indices = {}
    path_indices['original'] = onlinePermOOB_Path(
        df, batch_size = batch_size, ref_batch_size = ref_size,
        model_registry = model_registry, model_m = model_m)
    for i, indice in enumerate(indice_list):
        df_X = np.array(df[:, indice], dtype = float)
        df_Y = np.array(df[:, -1]).reshape(-1, 1)
        path_indices[i] = onlinePermOOB_Path(
            np.column_stack([df_X, df_Y]),
            batch_size = batch_size, ref_batch_size = ref_size,
            model_registry = model_registry, model_m = model_m)
    p_block = np.column_stack([path_indices[i]['pval'] for i in range(len(indice_list))])
    weights = np.ones(p_block.shape[1])
    path_indices['combined'] = {
        'cauchy': cauchy_aggregation(p_block, weights),
        'hmp': hmp_aggregation(p_block, weights),
        'simes': simes_aggregation(p_block),
        'fisher': fisher_aggregation(p_block),
        'stouffer': stouffer(p_block),
        'ssfed': ssfed_p(p_block),
    }
    for name in path_indices['combined']:
        path_indices['sig_addis_' + name] = method_addis(path_indices['combined'][name])
        path_indices['sig_saffron_' + name] = method_saffron(path_indices['combined'][name])
    return path_indices


'''
Aggregate the significance path:
Output the p_value paths as well as the recover rate -
The proportion of the values that aligns with the original paths of significance
The rank(spearman) correlation between the synthetic path and the sub-block paths.
'''
def aggregate_significance_path(path_indices):
    p_value_list_global = path_indices['original']['pval']
    sig_addis_global = path_indices['original']['sig_addis']
    sig_saffron_global = path_indices['original']['sig_saffron']
    subset_keys = [k for k in path_indices if isinstance(k, int) or (
        isinstance(k, str) and k.startswith('subset_'))]
    p_corr = np.asarray([
        spearmanr(p_value_list_global, path_indices[k]['pval'])[0]
        for k in subset_keys])
    addis_overlap = np.asarray([
        np.sum(sig_addis_global == path_indices[k]['sig_addis']) / len(sig_addis_global)
        for k in subset_keys])
    saffron_overlap = np.asarray([
        np.sum(sig_saffron_global == path_indices[k]['sig_saffron']) / len(sig_saffron_global)
        for k in subset_keys])
    recovery = {
        'addis': {'mean': float(np.mean(addis_overlap)), 'std': float(np.std(addis_overlap))},
        'saffron': {'mean': float(np.mean(saffron_overlap)), 'std': float(np.std(saffron_overlap))},
    }
    for name in path_indices['combined']:
        recovery[name] = {}
        for rule, sig_global in (('addis', sig_addis_global), ('saffron', sig_saffron_global)):
            sig_method = path_indices['combined_sig'][name][rule]
            recovery[name][rule] = float(np.sum(sig_global == sig_method) / len(sig_global))
    return {
        'p_value_paths': {
            'original': p_value_list_global,
            'subsets': {k: path_indices[k]['pval'] for k in subset_keys},
            'combined': path_indices['combined'],
        },
        'corr_p_value_path': {'mean': float(np.mean(p_corr)), 'std': float(np.std(p_corr))},
        'recovery': recovery,
    }


'''
Synthetic data example:
N = 40000
P = 200
N_BLOCKS = 10
BLOCK = P // N_BLOCKS
REF = 2000
BATCH = 10
CHANGE_ROW = 20000

def make_data(rng, kind):
    X = rng.normal(size = (N, P))
    signal = np.arange(N_BLOCKS) * BLOCK
    beta = np.zeros(P)
    beta[signal] = 0.8
    y = X @ beta + rng.normal(size = N)
    if kind == 'sparse':
        y[CHANGE_ROW:] += 2.2 * X[CHANGE_ROW:, signal[0]]
    elif kind == 'dense':
        for j in signal:
            y[CHANGE_ROW:] += 0.7 * X[CHANGE_ROW:, j]
    return np.column_stack([X, y])

indice_list = [list(range(b * BLOCK, (b + 1) * BLOCK)) for b in range(N_BLOCKS)]
#indice_list = np.array_split(np.arange(P), 10)
def run_one(seed, kind):
    rng = np.random.default_rng(seed)
    df = make_data(rng, kind)
    path_indices = aggregate_significance(
        df, indice_list, batch_size = BATCH, ref_size = REF)
    return aggregate_significance_path(path_indices)


'''































